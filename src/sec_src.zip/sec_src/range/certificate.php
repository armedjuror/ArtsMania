<?php
include "head.php";
?>
<section>
    <div class="container mt-5">
        <div id="final_list-box" style="min-height:700px;" class="text-center">
            <img src="../images/traffic-barrier.png" alt="">
            <h1 class="h1 text-center">This feature is not available right now.</h1>
        </div>
    </div>
</section>
<?php
include 'foot.php';
