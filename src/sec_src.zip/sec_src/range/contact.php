<?php
include "head.php";
?>

<section>
    <div class="container mt-5" style="min-height: 700px">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1 class="h1">സോഫ്റ്റ് വെയര്‍ സംബന്ധിച്ച സംശയങ്ങള്‍ക്ക് </h1>
                <img class="p-4" src="../images/icons/query.png" alt="query"><br><br>
                <a href="tel:+918129402602" class="btn btn-info m-4">Call Shinas - Member, SKSBV Tech Admins Kozhikode</a>
                <a href="tel:+919544143450" class="btn btn-info m-4">Call Fayas Mubaris - Member, SKSBV Tech Admins Kozhikode</a>
                <h1 class="h1"> DEVELOPERS </h1>
                <ul class="text-left h4 p-5">
                    <li class="pb-4">AJWAD JUMAN PC - CONVENER, SKSBV Tech Admins Kerala State</li>
                    <li>SUHAIL NM - CONVENER, SKSBV Tech Admins Kozhikode District</li>
                </ul>
                <h1 class="h2"> ഈ സോഫ്റ്റവെയറിനായി പ്രവര്‍ത്തിച്ച എല്ലാവരേയും നിങ്ങളുടെ പ്രാര്‍ത്ഥനകളില്‍ ഉള്‍പ്പെടുത്തുക. നാഥന്‍ അര്‍ഹമായ പ്രതിഫലം നല്‍കട്ടെ... </h1>
            </div>
        </div>
    </div>
</section>

<?php
include 'foot.php';
